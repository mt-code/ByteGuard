=================================================================
			MARKETPLACE README
=================================================================

Please do not open, modify, delete or move any files within this
folder. Doing so could cause a file corruption which can cause
issues with marketplace distribution.

If your program is marketplace registered and you believe these
files may be corrupt, please view the 'Update' tab while you are
in the program management options, this will allow you to update
and re-upload any neccesary files.